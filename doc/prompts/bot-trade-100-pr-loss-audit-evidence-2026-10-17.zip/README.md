Evidence reproduction · 17 October 2026

- §1 · Extract the complete ZIP into any directory.
  - Use Python 3 and its standard library; no network or project checkout is required.
  - Run `python3 /path/to/extracted/reconcile_statements.py` from any working directory.
  - The script verifies the five bundled text inputs against `attachment-manifest.json`.
  - It then rewrites `statement-reconciliation.json` from those inputs.
  - Expected latest-snapshot totals: SGD +21.81 on 43097342, USD −574.89 on 47790949,
    USD −70.58 on 46130058, and SGD −0.07 on 42993489.
  - The earlier 47790949 snapshot totals USD −536.23 and overlaps the later snapshot.

- §2 · Run `python3 /path/to/extracted/build_ledger.py` to regenerate both ledger formats and the ZIP.
  - This uses the bundled GitHub records and pinned 100-PR window, without refreshing them.
  - Regenerating the ZIP does not reproduce original ZIP timestamps byte-for-byte.

- §3 · Inspect `prs/<number>/merged.diff` and `production.diff` for every audited PR.
  - `pr-window.json` identifies their pinned merge commits and diff checksums.
  - A production diff can intentionally be empty for documentation-only changes.

- §4 · Package boundaries.
  - The original PDF uploads are not bundled; their filenames, sizes and SHA-256 hashes remain in the manifest.
  - Session-local PDF paths are provenance, not paths required by the scripts.
  - The extracted statement text is bundled and hashed for offline calculation reproduction.
  - Authenticated runtime receipts referenced by Claude's historical report are not available in this package.
  - This package reproduces the recorded calculations and evidence inventory, not private production observations.
