from pathlib import Path
from decimal import Decimal
from datetime import datetime
from collections import defaultdict
import re, json, hashlib

OUT=Path(__file__).resolve().parent
manifest=json.loads((OUT/'attachment-manifest.json').read_text())
for item in manifest:
    source=OUT/item['text']
    if hashlib.sha256(source.read_bytes()).hexdigest()!=item['text_sha256']:
        raise SystemExit(f"Statement text checksum mismatch: {item['text']}")
date=r'\d{1,2} [A-Za-z]{3} 2026 \d\d:\d\d:\d\d\.\d+'
pattern=re.compile(r'^DID(?P<deal>\d+)\s+(?P<order>\d+)\s+(?P<symbol>\S+)\s+(?P<side>Buy|Sell)\s+(?P<close_side>Buy|Sell)\s+(?P<opened>'+date+r')\s+(?P<closed>'+date+r')\s+(?P<entry>[\d.]+)\s+(?P<exit>[\d.]+)\s+(?P<lots>[\d.]+)\s+Lots\s+(?P<commission>-?[\d.]+)\s+(?P<pips>-?[\d.]+)\s+(?P<net>-?[\d.]+)\s+(?P<channel>.*?)\s+(?P<balance>\d[\d ]*\.\d+)\s*$')
def dt(s): return datetime.strptime(s,'%d %b %Y %H:%M:%S.%f')
def money(s): return Decimal(s.replace(' ',''))
results={}
for label in ['43097342','47790949-a','47790949-b','46130058','42993489']:
    text=(OUT/(label+'.txt')).read_text().replace('\xa0',' ')
    rows=[]; failures=[]
    for line in text.splitlines():
        line=line.strip()
        if not line.startswith('DID'): continue
        m=pattern.match(line)
        if not m: failures.append(line); continue
        row=m.groupdict(); row['hold_seconds']=(dt(row['closed'])-dt(row['opened'])).total_seconds()
        rows.append(row)
    rows.sort(key=lambda r:dt(r['closed']))
    unique=len({r['deal'] for r in rows})
    if failures or not rows or unique!=len(rows):
        raise SystemExit(f'{label}: missing rows, duplicate deals or unparsed deal lines')
    net=sum((money(r['net']) for r in rows),Decimal(0))
    gains=sum((money(r['net']) for r in rows if money(r['net'])>0),Decimal(0))
    losses=sum((money(r['net']) for r in rows if money(r['net'])<0),Decimal(0))
    commissions=sum((money(r['commission']) for r in rows),Decimal(0))
    opening=money(rows[0]['balance'])-money(rows[0]['net']) if rows else None
    mismatches=[]
    previous=opening
    for r in rows:
        if money(r['balance'])!=previous+money(r['net']): mismatches.append(r['deal'])
        previous=money(r['balance'])
    if mismatches:
        raise SystemExit(f'{label}: balance steps do not reconcile: {mismatches}')
    by_symbol=defaultdict(lambda:Decimal(0)); by_channel=defaultdict(lambda:Decimal(0)); by_day=defaultdict(lambda:Decimal(0)); groups=defaultdict(list)
    for r in rows:
        by_symbol[r['symbol']]+=money(r['net']); by_channel[r['channel']]+=money(r['net']); by_day[dt(r['closed']).strftime('%Y-%m-%d')]+=money(r['net'])
        groups[(r['symbol'],r['side'],r['opened'],r['entry'])].append(r)
    summary={'rows':len(rows),'unique_deals':unique,'parse_failures':failures,'net':str(net),'positive_net':str(gains),'negative_net':str(losses),'commissions_already_in_net':str(commissions),'deal_win_count':sum(money(r['net'])>0 for r in rows),'deal_loss_count':sum(money(r['net'])<0 for r in rows),'deal_zero_count':sum(money(r['net'])==0 for r in rows),'deal_pf_net':str(gains/abs(losses)) if losses else None,'opening_balance_inferred':str(opening),'last_deal_balance':str(previous),'balance_step_mismatches':mismatches,'first_close':rows[0]['closed'] if rows else None,'last_close':rows[-1]['closed'] if rows else None,'symbol_net':{k:str(v) for k,v in sorted(by_symbol.items(),key=lambda kv:kv[1])},'channel_net':{k:str(v) for k,v in by_channel.items()},'day_net':{k:str(v) for k,v in sorted(by_day.items())},'apparent_multi_close_groups':[[r['deal'] for r in group] for group in groups.values() if len(group)>1],'biggest_losses':sorted(rows,key=lambda r:money(r['net']))[:8]}
    results[label]={'summary':summary,'deals':rows}
    print(label,json.dumps(summary,indent=2))

old={r['deal']:r for r in results['47790949-a']['deals']}
new={r['deal']:r for r in results['47790949-b']['deals']}
common=set(old)&set(new)
delta=[r for k,r in new.items() if k not in old]
results['usd_snapshot_comparison']={'overlap_deals':len(common),'removed_deals':list(set(old)-set(new)),'changed_common':{k:{f:[old[k][f],new[k][f]] for f in old[k] if old[k][f]!=new[k][f]} for k in common if old[k]!=new[k]},'new_deals':delta,'incremental_net':str(sum((money(r['net']) for r in delta),Decimal(0)))}
print('SNAPSHOT COMPARISON',json.dumps(results['usd_snapshot_comparison'],indent=2))
(OUT/'statement-reconciliation.json').write_text(json.dumps(results,indent=2))
