from pathlib import Path
from datetime import datetime
import json,csv,collections,zipfile
R=Path(__file__).resolve().parent
window=json.load(open(R/'pr-window.json'))
docs={1393,1391,1389,1387,1386,1384,1373,1363,1349,1343,1342,1334,1324,1319,1316,1303}
research={1380,1367,1365,1355,1353,1332,1331,1330,1315,1314,1313,1312,1311,1310,1309,1308}
fault={1383,1385,1371,1370,1369,1368,1366}
ui={1377,1354,1351,1350,1347,1346,1345,1329,1323,1322,1307,1305,1304,1302,1301,1299,1298,1297,1296,1295,1294}
notes={1392:'Conditional OFF-policy bypass on runtime account enablement; late P1 remains in pinned source.',1391:'Plan only; entry-bar management-trigger P1 remains; no validated profit improvement.',1383:'Empty CI PR-body falls back to commit marker; reproduced traceability defect.',1387:'Prior loss report; incorrect historical commit/date attribution; raw private receipts unavailable here.',1389:'Adds reconciliation to the design; test finished after merge; no controller implementation.',1382:'Bar repair does not repair labels; explicit boundary exception; drop-only writes bypass row budget.',1390:'Owner-directed class routing; narrow retrospective cells; economic benefit unproven.',1376:'Implements +0.5R exit-side peak arming, merged after cited GER40/NAS100 losses.',1374:'Strategy premises become parseable; fill-band validation lacks noise-distance minimum.',1367:'Bar-form confirm uses bootstrap lower bound; does not qualify separate exit replay.',1365:'Train/confirm separation implemented for bar-form research.',1366:'Fault matrix deliberately retains explicit gaps; not system-wide certification.',1368:'Verifies receipts actually run/pass; does not independently validate every invariant.',1363:'Codex documentation PR; final-head test completed after merge.',1344:'Broker account-cost comparison is read/record only; gate integration remains separate.',1358:'NASA-4 broker conversion-rate recording; no gate integration.',1359:'NASA-3 filled/residual quantity contract; operational/financial acceptance separate.',1337:'Cost-aware fluid admission uses class schedule, not stored account-specific broker terms.',1306:'Keeper close receipts/recovery correction; proof of execution differs from profit proof.',1293:'Scanner committed-state rollback correction; foundation repair, not direct alpha.',1283:'Dependency maintenance; older PR number, included because merge occurred inside chronological window.'}
checks=[]; rows=[]
for p in window['prs']:
 n=p['number']; folder=R/'prs'/str(n); d=json.load(open(folder/'detail.json')); runs=json.load(open(folder/'checks.json'))['check_runs']; last={}
 for c in sorted(runs,key=lambda c:c['id']):
  if c['started_at'] and c['started_at']<=d['merged_at']: last[c['name']]=c
 states={k:(c['conclusion'] if c['completed_at'] and c['completed_at']<=d['merged_at'] else 'unfinished_at_merge') for k,c in last.items()}
 category='Documentation / plan / report' if n in docs else 'Research instrumentation / validation' if n in research else 'Fault assurance / boundary' if n in fault else 'UI / reporting / operational observability' if n in ui else 'Dependency maintenance' if n==1283 else 'Trading / broker-state / execution correction'
 row={'pr':n,'url':d['html_url'],'merged_at_utc':d['merged_at'],'merge_commit':p['sha'],'final_head':d['head']['sha'],'title':d['title'],'category':category,'file_count':len(p['files']),'files':'; '.join(p['files']),'checks_at_merge':'; '.join(f'{k}:{v}' for k,v in states.items()),'audit_note':notes.get(n,'Purpose and changed-file scope inventoried; acceptance and financial improvement are not inferred from merge status.')}
 rows.append(row)
with open(R/'100-pr-ledger.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
lines=['100-PR ledger · 17 October 2026','',f'- §1 · Pinned main: `{window["pin"]}`.','- §2 · Categories describe primary purpose; they are not correctness certifications.','- §3 · Check states are reconstructed at merge time from final-head check timestamps.','- §4 · Inventory covers all 100 PRs; detailed source findings appear in the accompanying audit.','','| PR | Purpose | Category | At merge | Audit note |','|---|---|---|---|---|']
for row in rows:
 clean=lambda x:str(x).replace('|','/').replace('\n',' ')
 lines.append('| ['+str(row['pr'])+']('+row['url']+') | '+clean(row['title'])+' | '+row['category']+' | '+clean(row['checks_at_merge'])+' | '+clean(row['audit_note'])+' |')
lines+=['','---','','- §5 · Interleaved direct commits are excluded from the 100-PR denominator.','']
for c in window['interleaved_direct_commits']: lines.append(f'  - `{c["sha"]}` · {c["when"]} · {c["title"]}')
(R/'100-pr-ledger.md').write_text('\n'.join(lines)+'\n')
print('CATEGORIES',dict(collections.Counter(row['category'] for row in rows)))
assert len(rows)==100 and len({row['pr'] for row in rows})==100
with zipfile.ZipFile(R/'bot-trade-100-pr-loss-audit-evidence-2026-10-17.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['README.md','bot-trade-100-pr-loss-audit-2026-10-17.md','100-pr-ledger.csv','100-pr-ledger.md','attachment-manifest.json','statement-reconciliation.json','pr-window.json','checks-at-merge.json','check-review-summary.json','boundary-empty-body-probe.json','public-health.json','reconcile_statements.py','build_ledger.py']:
  z.write(R/name,arcname=name)
 for item in json.load(open(R/'attachment-manifest.json')):
  z.write(R/item['text'],arcname=item['text'])
 for p in window['prs']:
  folder=R/'prs'/str(p['number'])
  for name in ['detail.json','reviews.json','comments.json','checks.json','merged.diff','production.diff']:
   z.write(folder/name,arcname=f'prs/{p["number"]}/{name}')
print('ARTIFACTS',[(p.name,p.stat().st_size) for p in R.iterdir() if p.name.endswith(('.md','.csv','.zip'))])
